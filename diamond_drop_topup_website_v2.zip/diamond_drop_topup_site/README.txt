DIAMOND DROP — player UID lookup + top-up storefront demo

HOW TO PREVIEW
1. Extract the ZIP.
2. Open index.html in a browser.
3. Keep assets/payment-qr.jpg alongside index.html when publishing.

UID LOOKUP
The page validates numeric UID format and carries it into the order form. It does NOT retrieve the real in-game player name/avatar or verify account existence. For that, integrate an authorized Free Fire data/top-up provider API on a secure backend. Do not scrape or ask for passwords/OTPs.

PAYMENTS
Static demo only: QR image is the supplied image, not independently verified. The page does not process/verify payments, send orders to a server, or deliver diamonds. Connect a legitimate payment gateway and authorized top-up provider before taking customer orders. Add privacy/refund/support terms and do not present this as an official Garena/Free Fire site.
